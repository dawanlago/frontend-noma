# Noma para WhatsApp

Extensão do Google Chrome que mostra, ao lado de cada conversa do WhatsApp Web, a negociação do contato no Noma.

## O que dá para fazer

- Identificar o contato da conversa pelo número (aceita com ou sem +55 e com ou sem o 9).
- Cadastrar o contato no Noma, ou vincular a um contato que já existe (salvando o número nele).
- Incluir em um funil (nome, funil, etapa e valor).
- Trocar o funil e a etapa.
- Alterar a temperatura (frio, morno, quente).
- Registrar parecer (fica no histórico da negociação, com autor e data).
- Criar tarefas e marcar como feitas.
- Contatos com mais de uma negociação: escolha qual acompanhar; dá para abrir uma nova.

Conversas em grupo não são vinculadas.

## Instalação (para a equipe)

O passo a passo completo, com o botão de download, está no próprio Noma: menu **Vendas → Extensão WhatsApp**.

1. Baixe esta pasta (`extension-noma`) para o computador.
2. No Chrome, abra `chrome://extensions`.
3. Ligue o **Modo do desenvolvedor** (canto superior direito).
4. Clique em **Carregar sem compactação** e escolha a pasta `extension-noma`.
5. Abra (ou recarregue) o **web.whatsapp.com**. O painel do Noma aparece à direita.
6. Entre com o mesmo e-mail e senha do Noma.

Para atualizar depois de uma nova versão: substitua os arquivos da pasta e clique no botão de recarregar da extensão em `chrome://extensions`; depois recarregue o WhatsApp Web.

## Configurações

No ícone da extensão (barra do Chrome) → **Configurações**:

- **Endereço da API**: padrão `https://backend-noma.vercel.app/api`.
- **Endereço do sistema**: o endereço do Noma no navegador, para o link "Abrir no Noma".

## Como funciona (técnico)

- `content.js` roda no WhatsApp Web, lê a conversa aberta (título do cabeçalho e o número que aparece
  nos identificadores das mensagens, `...@c.us`) e desenha o painel dentro de um Shadow DOM.
- `background.js` guarda o token de acesso e faz as chamadas à API; a página do WhatsApp nunca vê o token.
- O WhatsApp Web muda a estrutura da página de tempos em tempos. Se o painel parar de reconhecer as
  conversas, a leitura fica concentrada na função `readChat()` do `content.js`.
- Quando o número não aparece (algumas contas novas usam identificadores sem telefone), o painel oferece
  a busca manual na base.

## Publicar uma versão nova para a equipe

A extensão não está na Chrome Web Store: a equipe baixa o pacote pelo Noma.

1. Aumente `version` no `manifest.json`.
2. Gere o zip com a pasta `noma-whatsapp` (manifest, scripts, popup, ícones, brand e README) e
   substitua `frontend-noma/public/downloads/noma-whatsapp.zip`.
3. Atualize `EXTENSION_VERSION` em `frontend-noma/src/pages/extensao-whatsapp.tsx` e publique o frontend.
