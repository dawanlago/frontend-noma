// Service worker: guarda a sessão e faz as chamadas à API do Noma.
// As chamadas saem daqui (e não da página do WhatsApp) para não depender de CORS
// e para o token nunca ficar acessível à página.

const DEFAULT_API = "https://backend-noma.vercel.app/api";

async function settings() {
  const data = await chrome.storage.local.get(["apiUrl", "token", "user", "appUrl"]);
  return { apiUrl: (data.apiUrl || DEFAULT_API).replace(/\/+$/, ""), token: data.token || "", user: data.user || null, appUrl: data.appUrl || "" };
}

async function request({ method = "GET", path, body }) {
  const { apiUrl, token } = await settings();
  if (!token) return { ok: false, status: 401, error: "Entre com sua conta do Noma." };
  try {
    const response = await fetch(apiUrl + path, {
      method,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const json = response.status === 204 ? {} : await response.json().catch(() => ({}));
    if (response.status === 401) {
      await chrome.storage.local.remove(["token", "user"]);
      return { ok: false, status: 401, error: "Sessão expirada. Entre novamente." };
    }
    if (!response.ok) return { ok: false, status: response.status, error: json.error || "Não foi possível completar a ação." };
    return { ok: true, status: response.status, data: json.data };
  } catch {
    return { ok: false, status: 0, error: "Sem conexão com o Noma." };
  }
}

async function login({ email, password }) {
  const { apiUrl } = await settings();
  try {
    const response = await fetch(`${apiUrl}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const json = await response.json().catch(() => ({}));
    if (!response.ok || !json.token) return { ok: false, error: json.error || "Não foi possível entrar." };
    await chrome.storage.local.set({ token: json.token, user: { name: json.user?.name || "", email: json.user?.email || "" } });
    return { ok: true, user: json.user };
  } catch {
    return { ok: false, error: "Sem conexão com o Noma." };
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "api") {
    request(message).then(sendResponse);
    return true;
  }
  if (message?.type === "login") {
    login(message).then(sendResponse);
    return true;
  }
  if (message?.type === "logout") {
    chrome.storage.local.remove(["token", "user"]).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "session") {
    settings().then(({ token, user, appUrl }) => sendResponse({ loggedIn: Boolean(token), user, appUrl }));
    return true;
  }
  return false;
});
