// Service worker: guarda a sessão e faz as chamadas à API do Noma.
// As chamadas saem daqui (e não da página do WhatsApp) para não depender de CORS
// e para o token nunca ficar acessível à página.

const DEFAULT_API = "https://backend-noma.vercel.app/api";
const DEFAULT_APP = "https://noma-front.netlify.app";

/** Aceita o endereço do servidor com ou sem "/api" no final. */
function normalizeApi(value) {
  const url = String(value || DEFAULT_API).trim().replace(/\/+$/, "");
  return /\/api$/.test(url) ? url : `${url}/api`;
}

async function settings() {
  const data = await chrome.storage.local.get(["apiUrl", "token", "user", "appUrl", "orgId"]);
  return {
    apiUrl: normalizeApi(data.apiUrl),
    token: data.token || "",
    orgId: data.orgId || "",
    user: data.user || null,
    appUrl: (data.appUrl || DEFAULT_APP).trim().replace(/\/+$/, ""),
  };
}

function describeFailure(status, json) {
  if (json?.error) return json.error;
  if (status === 404) return "Endereço da API incorreto. Confira em Configurações da extensão.";
  if (status >= 500) return "O Noma está fora do ar no momento. Tente de novo em instantes.";
  return `Não foi possível completar a ação (erro ${status}).`;
}

async function request({ method = "GET", path, body }) {
  const { apiUrl, token, orgId } = await settings();
  if (!token) return { ok: false, status: 401, error: "Entre com sua conta do Noma." };
  try {
    const response = await fetch(apiUrl + path, {
      method,
      // Empresa escolhida no ícone da extensão (sem escolha: a primeira do usuário).
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}`, ...(orgId ? { "X-Org-Id": orgId } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const json = response.status === 204 ? {} : await response.json().catch(() => ({}));
    if (response.status === 401) {
      await chrome.storage.local.remove(["token", "user", "orgs", "orgId"]);
      return { ok: false, status: 401, error: "Sessão expirada. Entre novamente." };
    }
    if (!response.ok) return { ok: false, status: response.status, error: describeFailure(response.status, json) };
    return { ok: true, status: response.status, data: json.data };
  } catch {
    return { ok: false, status: 0, error: "Sem conexão com o Noma." };
  }
}

async function login({ email, password }) {
  const { apiUrl } = await settings();
  try {
    const response = await fetch(`${apiUrl}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const json = await response.json().catch(() => ({}));
    if (!response.ok || !json.token) return { ok: false, error: describeFailure(response.status, json) };
    const orgs = (json.user?.orgs || []).map((org) => ({ _id: org._id, name: org.name }));
    await chrome.storage.local.set({
      token: json.token,
      user: { name: json.user?.name || "", email: json.user?.email || "" },
      orgs,
      orgId: json.user?.orgId || orgs[0]?._id || "",
    });
    return { ok: true, user: json.user };
  } catch {
    return { ok: false, error: "Sem conexão com o Noma." };
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "api") {
    request(message).then(sendResponse);
    return true;
  }
  if (message?.type === "login") {
    login(message).then(sendResponse);
    return true;
  }
  if (message?.type === "logout") {
    chrome.storage.local.remove(["token", "user", "orgs", "orgId"]).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "session") {
    settings().then(({ token, user, appUrl }) => sendResponse({ loggedIn: Boolean(token), user, appUrl }));
    return true;
  }
  return false;
});
