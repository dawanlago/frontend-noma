const statusEl = document.getElementById("status");
const logoutBtn = document.getElementById("logout");
const apiUrl = document.getElementById("apiUrl");
const appUrl = document.getElementById("appUrl");
const orgBox = document.getElementById("orgBox");
const orgSelect = document.getElementById("org");

orgSelect.addEventListener("change", () => chrome.storage.local.set({ orgId: orgSelect.value }));

async function load() {
  const data = await chrome.storage.local.get(["token", "user", "apiUrl", "appUrl", "orgs", "orgId"]);
  // Quem trabalha em mais de uma empresa escolhe em qual a extensão cria e atualiza os registros.
  const orgs = data.token ? data.orgs || [] : [];
  orgBox.hidden = orgs.length < 2;
  orgSelect.innerHTML = "";
  for (const org of orgs) {
    const option = document.createElement("option");
    option.value = org._id;
    option.textContent = org.name;
    option.selected = org._id === data.orgId;
    orgSelect.append(option);
  }
  apiUrl.value = data.apiUrl || "";
  appUrl.value = data.appUrl || "";
  if (data.token) {
    statusEl.textContent = `Conectado como ${data.user?.name || data.user?.email || "usuário do Noma"}.`;
    logoutBtn.hidden = false;
  } else {
    statusEl.textContent = "Você ainda não entrou. Faça o login pelo painel no WhatsApp Web.";
    logoutBtn.hidden = true;
  }
}

logoutBtn.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "logout" });
  load();
});

document.getElementById("save").addEventListener("click", async () => {
  const clean = (value) => value.trim().replace(/\/+$/, "");
  const nextApi = clean(apiUrl.value);
  const current = await chrome.storage.local.get("apiUrl");
  // Trocar de servidor invalida a sessão atual.
  if ((current.apiUrl || "") !== nextApi) await chrome.storage.local.remove(["token", "user", "orgs", "orgId"]);
  await chrome.storage.local.set({ apiUrl: nextApi, appUrl: clean(appUrl.value) });
  document.getElementById("saved").style.display = "block";
  load();
});

load();
