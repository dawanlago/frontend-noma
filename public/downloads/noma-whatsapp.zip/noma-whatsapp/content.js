// Painel do Noma dentro do WhatsApp Web.
// Lê a conversa aberta (nome e telefone), encontra o contato no Noma e permite
// incluir no funil, mudar a etapa, a temperatura, registrar parecer e criar tarefas.
(() => {
  if (window.__nomaPanel) return;
  window.__nomaPanel = true;

  const PANEL_WIDTH = 360;
  const TEMPERATURES = [
    { value: "cold", label: "Frio" },
    { value: "warm", label: "Morno" },
    { value: "hot", label: "Quente" },
  ];
  const STATUS_LABELS = { open: "Em andamento", won: "Venda feita", lost: "Perdida" };

  /* ---------------- API (via service worker) ---------------- */

  function send(message) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (response) => resolve(response || { ok: false, error: "Extensão indisponível. Recarregue a página." }));
      } catch {
        resolve({ ok: false, error: "A extensão foi atualizada. Recarregue o WhatsApp Web." });
      }
    });
  }
  const api = (method, path, body) => send({ type: "api", method, path, body });

  /* ---------------- Conversa aberta ---------------- */

  // O WhatsApp envolve números em marcas invisíveis de direção do texto (ex.: "\u202a+55 73 8893-6370\u202c").
  const INVISIBLE = /[\u200e\u200f\u202a-\u202e\u2066-\u2069\ufeff]/g;
  const cleanText = (value) => String(value || "").replace(INVISIBLE, "").replace(/\u00a0/g, " ").trim();
  function phoneFromText(value) {
    const text = cleanText(value);
    return /^\+?[\d\s().-]{8,}$/.test(text) ? text.replace(/\D/g, "") : "";
  }
  const normalizeName = (value) =>
    cleanText(value)
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/\s+/g, " ");

  function firstPhoneIn(spans) {
    for (const span of spans) {
      // Só o texto do próprio elemento, para não juntar números de filhos diferentes.
      if (span.children.length) continue;
      const digits = phoneFromText(span.textContent);
      if (digits.length >= 10) return digits;
    }
    return "";
  }

  function readChat() {
    const main = document.querySelector("#main");
    if (!main) return null;
    const header = main.querySelector("header");
    const title = cleanText(header?.querySelector('span[dir="auto"]')?.textContent);
    const ids = Array.from(main.querySelectorAll("[data-id]"))
      .slice(-40)
      .map((el) => el.getAttribute("data-id") || "");
    const isGroup = ids.some((id) => id.includes("@g.us"));
    let phone = "";
    if (!isGroup) {
      for (const id of ids) {
        const match = id.match(/_(\d{8,15})@c\.us/);
        if (match) {
          phone = match[1];
          break;
        }
      }
      // Contas novas do WhatsApp não trazem o número nas mensagens: procura no título
      // (contato não salvo) e nos demais textos do cabeçalho.
      if (!phone) phone = phoneFromText(title);
      if (!phone && header) phone = firstPhoneIn(header.querySelectorAll("span"));
      // Painel "Dados do contato" aberto: fica fora da lista de conversas (#side) e da conversa (#main).
      if (!phone) {
        const side = document.getElementById("side");
        const drawerSpans = Array.from(document.querySelectorAll("#app span")).filter(
          (span) => !main.contains(span) && !(side && side.contains(span)),
        );
        phone = firstPhoneIn(drawerSpans);
      }
    }
    return { key: `${title}|${phone}|${isGroup}`, title, phone, isGroup };
  }

  function formatPhone(digits) {
    const d = digits.startsWith("55") && digits.length >= 12 ? digits.slice(2) : digits;
    if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
    if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
    return `+${digits}`;
  }

  const money = (value) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value || 0);
  const dateBR = (iso) => (iso ? iso.slice(0, 10).split("-").reverse().join("/") : "");
  const today = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  };

  /* ---------------- DOM seguro (nada de innerHTML com dados) ---------------- */

  function h(tag, props = {}, ...children) {
    const el = document.createElement(tag);
    for (const [key, value] of Object.entries(props || {})) {
      if (value === undefined || value === null || value === false) continue;
      if (key === "class") el.className = value;
      else if (key.startsWith("on")) el.addEventListener(key.slice(2).toLowerCase(), value);
      else if (key === "value") el.value = value;
      else if (key === "checked" || key === "disabled" || key === "selected") el[key] = Boolean(value);
      else el.setAttribute(key, value === true ? "" : String(value));
    }
    for (const child of children.flat()) {
      if (child === null || child === undefined || child === false) continue;
      el.append(child instanceof Node ? child : document.createTextNode(String(child)));
    }
    return el;
  }

  /* ---------------- Estrutura do painel ---------------- */

  const host = h("div", { id: "noma-whatsapp-panel" });
  const shadow = host.attachShadow({ mode: "open" });
  shadow.append(h("style", {}, STYLES()));
  const toggle = h(
    "button",
    { class: "toggle", title: "Noma", "aria-label": "Abrir painel do Noma" },
    h("img", { src: chrome.runtime.getURL("icons/icon48.png"), alt: "" }),
  );
  const panel = h("aside", { class: "panel" });
  const body = h("div", { class: "body" });
  panel.append(
    h(
      "header",
      { class: "top" },
      h("img", { class: "wordmark", src: chrome.runtime.getURL("brand/noma-vermelho.png"), alt: "Noma" }),
      h("span", { class: "spacer" }),
      h("button", { class: "icon", title: "Fechar", "aria-label": "Fechar", onClick: () => setOpen(false) }, "×"),
    ),
    body,
  );
  const toast = h("div", { class: "toast", role: "status" });
  panel.append(toast);
  shadow.append(toggle, panel);
  document.documentElement.append(host);

  let open = false;
  function setOpen(value) {
    open = value;
    panel.classList.toggle("open", open);
    toggle.classList.toggle("hidden", open);
    const app = document.getElementById("app");
    if (app) app.style.width = open ? `calc(100% - ${PANEL_WIDTH}px)` : "";
    chrome.storage.local.set({ panelOpen: open });
    if (open) refresh(true);
  }
  toggle.addEventListener("click", () => setOpen(true));
  chrome.storage.local.get("panelOpen").then(({ panelOpen }) => setOpen(panelOpen !== false));

  /* ---------------- Estado ---------------- */

  const state = {
    session: null,
    chat: null,
    funnels: [],
    contacts: null, // lista completa, carregada na busca manual ou pelo nome
    relationships: null, // tipos de relação (Lead, Cliente...) configurados no Noma
    matchedByName: false,
    contact: null,
    leads: [],
    leadId: "",
    lead: null,
    tasks: [],
    view: "main", // main | newLead | newContact | search
    notice: "",
    error: "",
    busy: false,
  };

  function render(...nodes) {
    body.replaceChildren(...nodes.flat().filter(Boolean));
  }

  // Erros de carregamento ficam fixos no topo; confirmações e erros de ação aparecem num aviso flutuante.
  function message() {
    return [state.error ? h("p", { class: "error" }, state.error) : null];
  }

  let toastTimer = 0;
  function showToast(text, kind) {
    toast.textContent = text;
    toast.className = `toast show ${kind}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (toast.className = "toast"), kind === "error" ? 5000 : 2500);
  }

  async function run(action, notice = "") {
    state.busy = true;
    state.error = "";
    const result = await action();
    state.busy = false;
    if (result && result.ok === false) showToast(result.error, "error");
    else if (notice) showToast(notice, "success");
    draw();
    return result;
  }

  /* ---------------- Carregamento ---------------- */

  let loadId = 0;
  async function refresh(force = false) {
    if (!open) return;
    const chat = readChat();
    if (!force && chat?.key === state.chat?.key) return;
    state.chat = chat;
    state.error = "";
    state.notice = "";
    state.view = "main";
    state.contact = null;
    state.leads = [];
    state.lead = null;
    state.tasks = [];
    const id = ++loadId;

    state.session = await send({ type: "session" });
    if (!state.session?.loggedIn) return draw();
    state.matchedByName = false;
    if (!chat || chat.isGroup || (!chat.phone && !chat.title)) return draw();

    render(h("p", { class: "muted" }, "Procurando o contato no Noma…"));
    const [contacts, funnels] = await Promise.all([
      chat.phone ? api("GET", `/contacts/by-phone?phone=${encodeURIComponent(chat.phone)}`) : { ok: true, data: [] },
      state.funnels.length ? { ok: true, data: state.funnels } : api("GET", "/funnels"),
    ]);
    if (id !== loadId) return;
    if (!contacts.ok) {
      state.error = contacts.error;
      return draw();
    }
    state.funnels = funnels.ok ? funnels.data : [];
    state.contact = contacts.data[0] || null;
    // Sem número (ou número diferente do cadastro): tenta pelo nome exato da conversa.
    if (!state.contact && chat.title && !phoneFromText(chat.title)) {
      if (!state.contacts) {
        const all = await api("GET", "/contacts");
        state.contacts = all.ok ? all.data : null;
      }
      if (id !== loadId) return;
      const wanted = normalizeName(chat.title);
      const byName = (state.contacts || []).filter((contact) => normalizeName(contact.name) === wanted);
      if (byName.length === 1) {
        state.contact = byName[0];
        state.matchedByName = true;
      }
    }
    if (state.contact) await loadLeads();
    if (id === loadId) draw();
  }

  async function loadLeads(selectId = "") {
    const result = await api("GET", `/leads?contactId=${state.contact._id}`);
    const order = { open: 0, won: 1, lost: 2 };
    state.leads = result.ok ? result.data.sort((a, b) => order[a.status] - order[b.status]) : [];
    state.leadId = selectId || state.leads[0]?._id || "";
    await loadLead();
  }

  async function loadLead() {
    state.lead = null;
    state.tasks = [];
    if (!state.leadId) return;
    const [lead, tasks] = await Promise.all([api("GET", `/leads/${state.leadId}`), api("GET", `/tasks?leadId=${state.leadId}`)]);
    state.lead = lead.ok ? lead.data : null;
    state.tasks = tasks.ok ? tasks.data : [];
  }

  /* ---------------- Telas ---------------- */

  function draw() {
    if (!state.session?.loggedIn) return render(loginView());
    const chat = state.chat;
    if (!chat) return render(h("p", { class: "empty" }, "Abra uma conversa para ver a negociação do contato no Noma."));
    if (chat.isGroup) return render(chatHeader(), h("p", { class: "empty" }, "Conversas em grupo não são vinculadas a negociações."));
    if (state.view === "search") return render(chatHeader(), ...message(), searchView());
    if (state.view === "newContact" || !state.contact) return render(chatHeader(), ...message(), newContactView());
    if (state.view === "newLead" || !state.leads.length) return render(chatHeader(), contactHeader(), ...message(), newLeadView());
    return render(chatHeader(), contactHeader(), ...message(), leadView());
  }

  function chatHeader() {
    const chat = state.chat;
    return h(
      "div",
      { class: "chat" },
      h("p", { class: "chat-title" }, chat.title || "Conversa"),
      chat.phone ? h("p", { class: "muted small" }, formatPhone(chat.phone)) : h("p", { class: "muted small" }, "Telefone não identificado"),
    );
  }

  function contactHeader() {
    const appUrl = state.session?.appUrl;
    const note = state.matchedByName
      ? h(
          "div",
          { class: "hint" },
          h("span", {}, state.chat.phone ? "Encontrado pelo nome: o número do WhatsApp não está no cadastro." : "Encontrado pelo nome da conversa."),
          state.chat.phone
            ? h(
                "button",
                {
                  class: "link",
                  onClick: () =>
                    run(async () => {
                      const result = await api("PATCH", `/contacts/${state.contact._id}`, { phone: formatPhone(state.chat.phone) });
                      if (result.ok) {
                        state.contact = result.data;
                        state.matchedByName = false;
                      }
                      return result;
                    }, "Número salvo no contato."),
                },
                "Salvar este número no contato",
              )
            : null,
        )
      : null;
    return h("div", { class: "stack tight-top" }, contactRow(appUrl), note);
  }

  function contactRow(appUrl) {
    return h(
      "div",
      { class: "row between contact" },
      h("span", {}, h("span", { class: "muted small" }, "Contato no Noma: "), h("strong", {}, state.contact.name)),
      h(
        "button",
        {
          class: "link",
          onClick: () => {
            state.view = "search";
            draw();
          },
        },
        "Trocar",
      ),
      appUrl ? h("a", { class: "link", href: `${appUrl.replace(/\/+$/, "")}/contatos/${state.contact._id}`, target: "_blank" }, "Abrir") : null,
    );
  }

  function loginView() {
    const email = h("input", { type: "email", placeholder: "E-mail", autocomplete: "username" });
    const password = h("input", { type: "password", placeholder: "Senha", autocomplete: "current-password" });
    const error = h("p", { class: "error hidden" });
    const submit = async (event) => {
      event.preventDefault();
      error.classList.add("hidden");
      const result = await send({ type: "login", email: email.value.trim(), password: password.value });
      if (!result.ok) {
        error.textContent = result.error;
        error.classList.remove("hidden");
        return;
      }
      refresh(true);
    };
    return h(
      "form",
      { class: "stack", onSubmit: submit },
      h("h2", {}, "Entre com sua conta do Noma"),
      h("p", { class: "muted small" }, "Use o mesmo e-mail e senha do sistema."),
      email,
      password,
      error,
      h("button", { class: "primary", type: "submit" }, "Entrar"),
    );
  }

  function newContactView() {
    const fromTitle = state.chat.title && !phoneFromText(state.chat.title) ? state.chat.title.replace(/\s*\((você|you)\)\s*$/i, "") : "";
    const name = h("input", { value: fromTitle, placeholder: "Nome do contato" });
    const phone = h("input", { value: state.chat.phone ? formatPhone(state.chat.phone) : "", placeholder: "(99) 99999-9999", inputmode: "tel" });
    const email = h("input", { type: "email", placeholder: "Opcional" });
    const addToFunnel = h("input", { type: "checkbox", checked: true });
    let kind = "lead";
    const kindBox = h("div", { class: "pills" });
    function drawKinds() {
      const options = state.relationships?.length
        ? state.relationships
        : [
            { value: "lead", label: "Lead" },
            { value: "client", label: "Cliente" },
            { value: "supplier", label: "Fornecedor" },
            { value: "partner", label: "Parceiro" },
          ];
      kindBox.replaceChildren(
        ...options.map((option) =>
          h(
            "button",
            {
              type: "button",
              class: `pill ${kind === option.value ? "active" : ""}`,
              onClick: () => {
                kind = option.value;
                drawKinds();
              },
            },
            option.label,
          ),
        ),
      );
    }
    drawKinds();
    if (!state.relationships) {
      api("GET", "/options?lists=relationship").then((result) => {
        state.relationships = result.ok ? result.data.map((item) => ({ value: item.value, label: item.label })) : [];
        drawKinds();
      });
    }

    const create = () =>
      run(async () => {
        if (!name.value.trim()) return { ok: false, error: "Informe o nome do contato." };
        const digits = phone.value.replace(/\D/g, "");
        // Evita duplicar: se o número já está no Noma, só vincula.
        if (digits.length >= 10) {
          const existing = await api("GET", `/contacts/by-phone?phone=${encodeURIComponent(digits)}`);
          if (existing.ok && existing.data.length) {
            state.contact = existing.data[0];
            state.view = "main";
            await loadLeads();
            return { ok: true, linked: true };
          }
        }
        const result = await api("POST", "/contacts", {
          name: name.value.trim(),
          phone: phone.value.trim(),
          email: email.value.trim(),
          kinds: [kind],
        });
        if (!result.ok) return result;
        state.contact = result.data;
        state.matchedByName = false;
        await loadLeads();
        state.view = addToFunnel.checked ? "newLead" : "main";
        return result;
      }).then((result) => {
        if (result?.linked) showToast("Esse número já estava no Noma: contato vinculado.", "success");
        else if (result?.ok) showToast("Contato adicionado ao Noma.", "success");
      });

    return h(
      "form",
      {
        class: "stack",
        onSubmit: (event) => {
          event.preventDefault();
          create();
        },
      },
      h("h2", {}, "Adicionar ao Noma"),
      h("p", { class: "muted small" }, "Este contato ainda não está na base. Confira os dados da conversa e adicione."),
      state.chat.phone
        ? null
        : h(
            "p",
            { class: "hint" },
            "Não consegui ler o número desta conversa. Clique no nome no topo da conversa para abrir os dados do contato no WhatsApp, ou digite o número abaixo.",
          ),
      h("label", {}, "Nome", name),
      h("label", {}, "Telefone / WhatsApp", phone),
      h("label", {}, "E-mail", email),
      h("div", { class: "field" }, h("span", { class: "field-label" }, "Tipo"), kindBox),
      h("label", { class: "check" }, addToFunnel, "Depois, incluir em um funil"),
      h("button", { class: "primary", type: "submit", disabled: state.busy }, "Adicionar contato"),
      h(
        "button",
        {
          class: "secondary",
          type: "button",
          onClick: () => {
            state.view = "search";
            draw();
          },
        },
        "Já existe no Noma? Vincular",
      ),
    );
  }

  function searchView() {
    const input = h("input", { placeholder: "Buscar por nome", value: phoneFromText(state.chat.title) ? "" : state.chat.title || "" });
    const list = h("ul", { class: "list" });
    const savePhone = h("input", { type: "checkbox", checked: Boolean(state.chat.phone) });
    const normalize = (value) =>
      value
        .normalize("NFD")
        .replace(/[̀-ͯ]/g, "")
        .toLowerCase();

    function fill() {
      const term = normalize(input.value.trim());
      const matches = (state.contacts || []).filter((contact) => !term || normalize(contact.name).includes(term)).slice(0, 8);
      list.replaceChildren(
        ...(matches.length
          ? matches.map((contact) =>
              h(
                "li",
                {},
                h(
                  "button",
                  {
                    class: "pick",
                    onClick: () =>
                      run(async () => {
                        let chosen = contact;
                        if (savePhone.checked && state.chat.phone) {
                          const result = await api("PATCH", `/contacts/${contact._id}`, { phone: formatPhone(state.chat.phone) });
                          if (!result.ok) return result;
                          chosen = result.data;
                        }
                        state.contact = chosen;
                        state.view = "main";
                        await loadLeads();
                        return { ok: true };
                      }, "Contato vinculado."),
                  },
                  h("strong", {}, contact.name),
                  h("span", { class: "muted small" }, contact.phone || contact.email || "Sem telefone"),
                ),
              ),
            )
          : [h("li", { class: "muted small" }, state.contacts ? "Nenhum contato encontrado." : "Carregando contatos…")]),
      );
    }

    input.addEventListener("input", fill);
    if (!state.contacts) {
      api("GET", "/contacts").then((result) => {
        state.contacts = result.ok ? result.data : [];
        fill();
      });
    }
    fill();
    return h(
      "div",
      { class: "stack" },
      h("h2", {}, "Vincular a um contato do Noma"),
      input,
      list,
      state.chat.phone ? h("label", { class: "check" }, savePhone, "Salvar este número no contato escolhido") : null,
      h(
        "button",
        {
          class: "secondary",
          onClick: () => {
            state.view = state.contact ? "main" : "newContact";
            draw();
          },
        },
        state.contact ? "Voltar" : "Cadastrar como novo contato",
      ),
    );
  }

  function funnelSelects(initialFunnelId = "", initialStageId = "") {
    const funnelSelect = h(
      "select",
      {},
      state.funnels.map((funnel) => h("option", { value: funnel._id, selected: funnel._id === initialFunnelId }, funnel.name)),
    );
    const stageSelect = h("select", {});
    function fillStages(stageId = "") {
      const funnel = state.funnels.find((item) => item._id === funnelSelect.value);
      stageSelect.replaceChildren(
        ...(funnel?.stages || []).map((stage) => h("option", { value: stage._id, selected: stage._id === stageId }, stage.name)),
      );
    }
    funnelSelect.addEventListener("change", () => fillStages());
    fillStages(initialStageId);
    return { funnelSelect, stageSelect };
  }

  function newLeadView() {
    if (!state.funnels.length) return h("p", { class: "empty" }, "Nenhum funil cadastrado no Noma.");
    const { funnelSelect, stageSelect } = funnelSelects(state.funnels[0]._id);
    const name = h("input", { value: state.contact.name, placeholder: "Nome da negociação" });
    const value = h("input", { inputmode: "decimal", placeholder: "Opcional, ex.: 3500" });
    return h(
      "div",
      { class: "stack" },
      h("h2", {}, state.leads.length ? "Nova negociação" : "Incluir em um funil"),
      h("label", {}, "Nome da negociação", name),
      h("label", {}, "Funil", funnelSelect),
      h("label", {}, "Etapa", stageSelect),
      h("label", {}, "Valor (R$)", value),
      h(
        "button",
        {
          class: "primary",
          disabled: state.busy,
          onClick: () =>
            run(async () => {
              const amount = Number(value.value.replace(/\./g, "").replace(",", ".")) || 0;
              const result = await api("POST", "/leads", {
                name: name.value.trim() || state.contact.name,
                contactId: state.contact._id,
                funnelId: funnelSelect.value,
                stageId: stageSelect.value,
                customValue: amount,
              });
              if (!result.ok) return result;
              state.view = "main";
              await loadLeads(result.data._id);
              return result;
            }, "Negociação incluída no funil."),
        },
        "Incluir no funil",
      ),
      state.leads.length
        ? h(
            "button",
            {
              class: "secondary",
              onClick: () => {
                state.view = "main";
                draw();
              },
            },
            "Cancelar",
          )
        : null,
    );
  }

  function leadView() {
    const lead = state.lead;
    const leadPicker =
      state.leads.length > 1
        ? h(
            "select",
            {
              onChange: (event) =>
                run(async () => {
                  state.leadId = event.target.value;
                  await loadLead();
                  return { ok: true };
                }),
            },
            state.leads.map((item) =>
              h("option", { value: item._id, selected: item._id === state.leadId }, `${item.name} · ${STATUS_LABELS[item.status] || ""}`),
            ),
          )
        : null;

    if (!lead) return h("div", { class: "stack" }, leadPicker, h("p", { class: "muted" }, "Carregando negociação…"));

    const funnel = state.funnels.find((item) => item._id === lead.funnelId);
    const { funnelSelect, stageSelect } = funnelSelects(lead.funnelId, lead.stageId);
    const saveStage = () =>
      run(async () => {
        const result = await api("PATCH", `/leads/${lead._id}`, { funnelId: funnelSelect.value, stageId: stageSelect.value });
        if (result.ok) {
          state.lead = { ...state.lead, ...result.data };
          state.leads = state.leads.map((item) => (item._id === lead._id ? { ...item, ...result.data } : item));
        }
        return result;
      }, "Etapa atualizada.");
    funnelSelect.addEventListener("change", saveStage);
    stageSelect.addEventListener("change", saveStage);

    const appUrl = state.session?.appUrl;
    return h(
      "div",
      { class: "stack" },
      leadPicker,
      h(
        "section",
        { class: "card" },
        h(
          "div",
          { class: "row between" },
          h("strong", { class: "lead-name" }, lead.name),
          h("span", { class: `chip ${lead.status}` }, STATUS_LABELS[lead.status] || ""),
        ),
        h("p", { class: "value" }, money(lead.value)),
        appUrl ? h("a", { class: "link", href: `${appUrl.replace(/\/+$/, "")}/crm/${lead._id}`, target: "_blank" }, "Abrir no Noma ↗") : null,
      ),

      h("section", { class: "stack tight" }, h("h3", {}, "Funil e etapa"), state.funnels.length > 1 ? funnelSelect : h("p", { class: "muted small" }, funnel?.name || ""), stageSelect),

      h(
        "section",
        { class: "stack tight" },
        h("h3", {}, "Temperatura"),
        h(
          "div",
          { class: "segmented" },
          TEMPERATURES.map((item) =>
            h(
              "button",
              {
                class: `seg ${item.value} ${lead.temperature === item.value ? "active" : ""}`,
                disabled: state.busy,
                onClick: () =>
                  run(async () => {
                    const result = await api("PATCH", `/leads/${lead._id}`, { temperature: item.value });
                    if (result.ok) state.lead = { ...state.lead, temperature: item.value };
                    return result;
                  }, "Temperatura atualizada."),
              },
              item.label,
            ),
          ),
        ),
      ),

      commentsSection(lead),
      tasksSection(lead),

      h(
        "button",
        {
          class: "secondary",
          onClick: () => {
            state.view = "newLead";
            draw();
          },
        },
        "+ Nova negociação para este contato",
      ),
    );
  }

  function commentsSection(lead) {
    const text = h("textarea", { rows: 3, placeholder: "Registre o que foi conversado, próximos passos…" });
    const comments = [...(lead.comments || [])].reverse().slice(0, 3);
    return h(
      "section",
      { class: "stack tight" },
      h("h3", {}, "Parecer"),
      text,
      h(
        "button",
        {
          class: "primary small",
          disabled: state.busy,
          onClick: () =>
            run(async () => {
              if (!text.value.trim()) return { ok: false, error: "Escreva o parecer." };
              const result = await api("POST", `/leads/${lead._id}/comments`, { text: text.value.trim() });
              if (result.ok) state.lead = { ...state.lead, comments: result.data.comments };
              return result;
            }, "Parecer registrado."),
        },
        "Registrar parecer",
      ),
      comments.length
        ? h(
            "ul",
            { class: "comments" },
            comments.map((comment) =>
              h(
                "li",
                {},
                h("p", {}, comment.text),
                h("span", { class: "muted small" }, [comment.authorName, dateBR(comment.createdAt)].filter(Boolean).join(" · ")),
              ),
            ),
          )
        : null,
    );
  }

  function tasksSection(lead) {
    const title = h("input", { placeholder: "Nova tarefa" });
    const date = h("input", { type: "date", value: today() });
    const time = h("input", { type: "time" });
    const pending = state.tasks.filter((task) => !task.done);
    const done = state.tasks.filter((task) => task.done).slice(-2);
    const item = (task) =>
      h(
        "li",
        { class: task.done ? "done" : "" },
        h(
          "label",
          { class: "check" },
          h("input", {
            type: "checkbox",
            checked: task.done,
            onChange: () =>
              run(async () => {
                const result = await api("PATCH", `/tasks/${task._id}`, { done: !task.done });
                if (result.ok) state.tasks = state.tasks.map((t) => (t._id === task._id ? { ...t, ...result.data } : t));
                return result;
              }),
          }),
          h(
            "span",
            {},
            task.title,
            task.dueDate ? h("span", { class: `muted small ${!task.done && task.dueDate < today() ? "late" : ""}` }, ` · ${dateBR(task.dueDate)}${task.time ? ` ${task.time}` : ""}`) : null,
          ),
        ),
      );
    return h(
      "section",
      { class: "stack tight" },
      h("h3", {}, "Tarefas"),
      pending.length || done.length ? h("ul", { class: "tasks" }, [...pending, ...done].map(item)) : h("p", { class: "muted small" }, "Nenhuma tarefa ainda."),
      title,
      h("div", { class: "row" }, date, time),
      h(
        "button",
        {
          class: "primary small",
          disabled: state.busy,
          onClick: () =>
            run(async () => {
              if (!title.value.trim()) return { ok: false, error: "Escreva a tarefa." };
              const result = await api("POST", "/tasks", { title: title.value.trim(), dueDate: date.value, time: time.value, leadId: lead._id });
              if (result.ok) state.tasks = [...state.tasks, result.data];
              return result;
            }, "Tarefa criada."),
        },
        "Adicionar tarefa",
      ),
    );
  }

  /* ---------------- Observa a troca de conversa ---------------- */

  setInterval(() => refresh(false), 800);
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.token || changes.appUrl) refresh(true);
  });

  function STYLES() {
    return `
      :host { all: initial; }
      * { box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
      .toggle { position: fixed; right: 0; top: 45%; z-index: 2147483000; width: 36px; height: 44px; border: 0; border-radius: 10px 0 0 10px;
        background: #731817; color: #fff; font-weight: 800; font-size: 16px; cursor: pointer; box-shadow: 0 4px 16px rgba(0,0,0,.18); }
      .toggle.hidden { display: none; }
      .toggle img { width: 26px; height: 26px; display: block; margin: auto; border-radius: 6px; }
      .panel { position: fixed; top: 0; right: 0; z-index: 2147483000; width: ${PANEL_WIDTH}px; height: 100vh; background: #fff; color: #111827;
        border-left: 1px solid #e5e7eb; display: none; flex-direction: column; font-size: 14px; }
      .panel.open { display: flex; }
      .top { display: flex; align-items: center; gap: 8px; padding: 14px 16px; border-bottom: 1px solid #eef0f3; }
      .wordmark { height: 22px; width: auto; display: block; }
      .logo { width: 26px; height: 26px; border-radius: 8px; background: #731817; color: #fff; display: grid; place-items: center; font-weight: 800; font-size: 13px; }
      .spacer { flex: 1; }
      .icon { border: 0; background: none; font-size: 22px; line-height: 1; cursor: pointer; color: #6b7280; padding: 4px 6px; border-radius: 6px; }
      .icon:hover { background: #f3f4f6; }
      .body { flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 14px; }
      h2 { font-size: 16px; margin: 0; }
      h3 { font-size: 12px; margin: 0; text-transform: uppercase; letter-spacing: .06em; color: #6b7280; }
      p { margin: 0; }
      .stack { display: flex; flex-direction: column; gap: 12px; }
      .stack.tight { gap: 8px; padding-top: 12px; border-top: 1px solid #f0f1f4; }
      .row { display: flex; gap: 8px; align-items: center; }
      .row > * { flex: 1; }
      .between { justify-content: space-between; }
      .between > * { flex: initial; }
      label { display: flex; flex-direction: column; gap: 6px; font-size: 12px; font-weight: 600; color: #374151; }
      input, select, textarea { width: 100%; border: 1px solid #d9dde3; border-radius: 10px; padding: 9px 11px; font-size: 14px; color: #111827; background: #fff; outline: none; }
      input:focus, select:focus, textarea:focus { border-color: #731817; box-shadow: 0 0 0 3px rgba(115,24,23,.15); }
      textarea { resize: vertical; }
      button { font-size: 14px; }
      .primary, .secondary { border: 0; border-radius: 10px; padding: 10px 14px; font-weight: 700; cursor: pointer; }
      .primary { background: #731817; color: #fff; }
      .primary:hover { background: #5c1312; }
      .primary.small { padding: 8px 12px; font-size: 13px; align-self: flex-start; }
      .secondary { background: #f8ecec; color: #731817; }
      button:disabled { opacity: .6; cursor: default; }
      .link { border: 0; background: none; color: #731817; font-weight: 700; cursor: pointer; font-size: 13px; text-decoration: none; padding: 0; }
      .muted { color: #6b7280; }
      .small { font-size: 12px; }
      .empty { color: #6b7280; text-align: center; padding: 32px 8px; line-height: 1.5; }
      .error { color: #b42318; background: #fef3f2; border-radius: 8px; padding: 8px 10px; font-size: 13px; }
      .notice { color: #067647; background: #ecfdf3; border-radius: 8px; padding: 8px 10px; font-size: 13px; }
      .hidden { display: none; }
      .chat { padding-bottom: 12px; border-bottom: 1px solid #f0f1f4; }
      .chat-title { font-weight: 700; font-size: 15px; }
      .contact { font-size: 13px; gap: 10px; }
      .card { border: 1px solid #e5e7eb; border-radius: 12px; padding: 12px 14px; display: flex; flex-direction: column; gap: 4px; }
      .lead-name { font-size: 15px; }
      .value { font-size: 18px; font-weight: 700; }
      .chip { font-size: 11px; font-weight: 700; border-radius: 999px; padding: 3px 8px; background: #f8ecec; color: #731817; white-space: nowrap; }
      .chip.won { background: #ecfdf3; color: #067647; }
      .chip.lost { background: #fef3f2; color: #b42318; }
      .segmented { display: grid; grid-template-columns: repeat(3, 1fr); gap: 4px; background: #f3f4f6; padding: 4px; border-radius: 10px; }
      .seg { border: 0; background: none; border-radius: 7px; padding: 7px; font-weight: 700; font-size: 13px; color: #6b7280; cursor: pointer; }
      .seg.active.cold { background: #e0f2fe; color: #0369a1; }
      .seg.active.warm { background: #fef3c7; color: #b45309; }
      .seg.active.hot { background: #fee4e2; color: #b42318; }
      .list, .comments, .tasks { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 6px; }
      .pick { width: 100%; text-align: left; border: 1px solid #e5e7eb; background: #fff; border-radius: 10px; padding: 8px 10px; cursor: pointer; display: flex; flex-direction: column; gap: 2px; }
      .pick:hover { border-color: #731817; }
      .comments li { background: #f7f8fa; border-radius: 10px; padding: 8px 10px; display: flex; flex-direction: column; gap: 4px; white-space: pre-line; }
      .check { flex-direction: row; align-items: flex-start; gap: 8px; font-weight: 500; font-size: 13px; color: #111827; }
      .check input { width: auto; margin-top: 2px; }
      .tasks li.done span { text-decoration: line-through; color: #9ca3af; }
      .late { color: #b42318; font-weight: 700; }
      .tight-top { gap: 8px; }
      .field { display: flex; flex-direction: column; gap: 6px; }
      .field-label { font-size: 12px; font-weight: 600; color: #374151; }
      .pills { display: flex; flex-wrap: wrap; gap: 6px; }
      .pill { border: 1px solid #d9dde3; background: #fff; border-radius: 999px; padding: 6px 12px; font-size: 13px; font-weight: 600; color: #374151; cursor: pointer; }
      .pill.active { background: #731817; border-color: #731817; color: #fff; }
      .hint { background: #fffaeb; color: #93370d; border-radius: 8px; padding: 8px 10px; font-size: 12px; display: flex; flex-direction: column; gap: 4px; align-items: flex-start; }
      .toast { position: absolute; left: 16px; right: 16px; bottom: 16px; padding: 10px 12px; border-radius: 10px; font-size: 13px; font-weight: 600;
        opacity: 0; transform: translateY(8px); transition: opacity .2s, transform .2s; pointer-events: none; box-shadow: 0 8px 24px rgba(0,0,0,.12); }
      .toast.show { opacity: 1; transform: none; }
      .toast.success { background: #ecfdf3; color: #067647; }
      .toast.error { background: #fef3f2; color: #b42318; }
      .panel { position: fixed; }
    `;
  }
})();
